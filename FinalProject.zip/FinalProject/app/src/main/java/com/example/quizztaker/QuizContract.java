package com.example.quizztaker;
/**
 * Source-https://codinginflow.com/tutorials/android/quiz-app-with-sqlite/part-3-sqliteopenhelper
 */
import android.provider.BaseColumns;

public final class QuizContract {

    //default class constructor
    private QuizContract() {}

    public static class QuestionsTable implements BaseColumns {

        public static final String TABLE_NAME = "quiz_questions";
        public static final String COLUMN_QUESTION = "question";
        public static final String COLUMN_CATEGORY = "category";
        public static final String COLUMN_ChoiceA = "optionA";
        public static final String COLUMN_ChoiceB = "optionB";
        public static final String COLUMN_ChoiceC = "optionC";
        public static final String COLUMN_ChoiceD = "optionD";

        public static final String COLUMN_ANSWER_NR = "answer_nr";

    }
}
