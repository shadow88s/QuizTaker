package com.example.quizztaker;

public class Question {

    private String question;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    private String category;
    private String choiceA;
    private String choiceB;
    private String choiceC;
    private String choiceD;
    private int answerNumberr; //the correct choice that is correct;
    //default constructor with no arguments
    public Question() {}

    public Question(String question, String category, String choiceA, String choiceB, String choiceC, String choiceD, int answerNumberr) {
        this.question = question;
        this.category = category;
        this.choiceA = choiceA;
        this.choiceB = choiceB;
        this.choiceC = choiceC;
        this.choiceD = choiceD;
        this.answerNumberr = answerNumberr;
}

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getChoiceA() {
        return choiceA;
    }

    public void setChoiceA(String choiceA) {
        this.choiceA = choiceA;
    }

    public String getChoiceB() {
        return choiceB;
    }

    public void setChoiceB(String choiceB) {
        this.choiceB = choiceB;
    }

    public String getChoiceC() {
        return choiceC;
    }

    public void setChoiceC(String choiceC) {
        this.choiceC = choiceC;
    }

    public String getChoiceD() {
        return choiceD;
    }

    public void setChoiceD(String choiceD) {
        this.choiceD = choiceD;
    }

    public int getAnswerNumberr() {
        return answerNumberr;
    }

    public void setAnswerNumberr(int answerNumberr) {
        this.answerNumberr = answerNumberr;
    }
}
