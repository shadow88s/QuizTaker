package com.example.quizztaker;
/**
 * Source-https://codinginflow.com/tutorials/android/quiz-app-with-sqlite/part-3-sqliteopenhelper
 */

import com.example.quizztaker.QuizContract.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    //Constants for SQLite database
    private static final String DATABASE_NAME = "QuizQuestions";
    private static final int DATABASE_Version = 1;

    //used as a reference to add some values
    private SQLiteDatabase db;

    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME,null, DATABASE_Version );
    }

    /**
     * method will be called when database is first accessed thjs is where
     * we creater our database
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        //string for SQL table creation
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_CATEGORY+ " TEXT, " +
                QuestionsTable.COLUMN_ChoiceA + " TEXT, " +
                QuestionsTable.COLUMN_ChoiceB+ " TEXT, " +
                QuestionsTable.COLUMN_ChoiceC + " TEXT, "  +
                QuestionsTable.COLUMN_ChoiceD + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER" +
                ")";
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    //fills questions into Questions table
    private void fillQuestionsTable(){

        //Creates New question Objects
        Question q1 = new Question("History", "World War I began in which year?",
                " 1923", "1938", " 1917", "1914", 4);
        addQuestion(q1); //adds a Question to database

        Question q2 = new Question("History","Adolf Hitler was born in which " +
                "country?", " France", "Germany",  " Austria",
                "Hungary", 3);
        addQuestion(q2); //adds a Question to database

        Question q3 = new Question("History","John F. Kennedy was assassinated in: ",
                "New York", "Austin", "Dallas", "Miami",
                3);
        addQuestion(q3); //adds a Question to database
        Question q4 = new Question("History","Who fought in the war of 1812?",
                "Andrew Jackson", "Arthur Wellsley", "Otto von Bismarck",
                "Napoleon", 1);
        addQuestion(q4); //adds a Question to database

        Question q5 = new Question("History","Which general famously stated 'I shall return'?",
                "Bull Halsey", "George Patton", "Douglas MacArthur",
                "Omar Bradley", 3);
        addQuestion(q5); //adds a Question to database

        Question q6 = new Question("History","American involvement in the Korean " +
                "war took place in which decade?", "1970s", "1950s", "1920s",
                "1960s", 2);
        addQuestion(q6); //adds a Question to database

        Question q7 = new Question("History","Battle of Hastings in 1066 was " +
                "fought in which country?", "France", "Russia", "England",
                "Norway", 3);
        addQuestion(q7); //adds a Question to database

        Question q8 = new Question("History","The Magna Carta was published by the" +
                " King of which country?", " France", "Austria", "Italy",
                "England", 4);
        addQuestion(q8); //adds a Question to database

        Question q9 = new Question("History","The first successful printing press" +
                " was developed by _____.", " Johannes Gutenburg", "Benjamin Franklin",
                "Sir Issac Newton", "Martin Luther", 1);
        addQuestion(q9); //adds a Question to database


        Question q10 = new Question("History","The disease that ravaged and killed " +
                "a third of Europe's population in the 14th century is known as:",
                "The White Death", "The Black Plaque", "Smallpox",
                "The Bubonic Plaque", 4);
        addQuestion(q10); //adds a Question to database

        Question q11 = new Question("Astronomy","At any time we may describe " +
                "the position of an inferior planet by the angle it makes with the sun as seen " +
                "from the earth. This angle is called the:", " ecliptic (pron: eh-klip-tik) ",
                "epicycle", "elongation", "proxima",
                3);
        addQuestion(q11); //adds a Question to database
        Question q12 = new Question("Astronomy","Which of the following planets" +
                " has the greatest eccentricity?", "Pluto", "Jupiter", "Mars",
                "Mercury", 1);
        addQuestion(q12); //adds a Question to database
        Question q13 = new Question("Astronomy","The largest moon in our solar" +
                " system has an atmosphere that is denser than the atmosphere of Mars. The name of" +
                "this moon is:", "Titan", "Ganymede", "Triton",
                "Io (pron: I - O)", 1);
        addQuestion(q13); //adds a Question to database
        Question q14 = new Question("Astronomy","On which of the following " +
                "planets would the sun rise in the west?", "Saturn", "Pluto",
                "Mercury", "Venus", 4);
        addQuestion(q14); //adds a Question to database
        Question q15 = new Question("Astronomy","Which planet seems to be turned" +
                " on its side with an axis tilt of 98 degrees?", "Uranus",
                "Pluto", "Neptune", "Saturn",
                1);
        addQuestion(q15); //adds a Question to database
        Question q16 = new Question("Astronomy","The angle that the full moon" +
                " takes up in the night sky is equal to which of the following values?",
                "1/8 degree", "1/2 degree", " 1 degree",
                "2 degrees", 2);
        addQuestion(q16); //adds a Question to database
        Question q17 = new Question("Astronomy","The period from one full moon to the next is:",
                "33 days", "30 days", "29.5 days",
                "28 days", 3);
        addQuestion(q17); //adds a Question to database
        Question q18 = new Question("Astronomy","When a superior planet is at" +
                " opposition it is making an angle of how many degrees with the sun?",
                " 0 degrees", "45 degrees", "90 degrees",
                "180 degrees", 4);
        addQuestion(q18); //adds a Question to database
        Question q19 = new Question("Astronomy","The word Albedo " +
                "(pron: al-BEE-doe) refers to which of the following?", "The wobbling" +
                " motion of a planet", "The amount of light a planet reflects",
                "The phase changes of a planet", "The brightness of a star",
                2);
        addQuestion(q19); //adds a Question to database
        Question q20 = new Question("Astronomy","Galileo discovered something " +
                "about Venus with his telescope that shook the old theories. Which of the following" +
                " was Galileo's discovery?",
                " Venus was covered in clouds", "Venus had phases like the moon",
                "Venus' surface was similar to the earth's", "Venus had retrograde" +
                " motion", 2);
        addQuestion(q20); //adds a Question to database
        Question q21 = new Question("Biology","During photosynthesis:",
                "light reactions produce sugar, while the Calvin cycle produces O2.",
                "light reactions produce NADPH and ATP, while the Calvin cycle produces sugar.",
                "light reactions photophosphorylate ADP, while the Calvin cycle produces ATP.",
                "the Calvin cycle produces both sugar and O2.", 2);
        addQuestion(q21); //adds a Question to database
        Question q22 = new Question("Biology","The adult human of average age " +
                "and size has approximately how many quarts of blood?", "4", "6",
                "8", "10", 2);
        addQuestion(q22); //adds a Question to database
        Question q23 = new Question("Biology","Once the erythrocytes enter the" +
                " blood in humans, it is estimated that they have an average lifetime of how many" +
                " days. Is it:", "10 days", "120 days", "200 days",
                "360 days", 2);
        addQuestion(q23); //adds a Question to database
        Question q24 = new Question("Biology","Of the following, which " +
                "mechanisms are important in the death of erythrocytes (pron: eh-rith-reh-sites)" +
                " in human blood? Is it",
                "phagocytosis (pron: fag-eh-seh-toe-sis)", "hemolysis",
                " mechanical damage",
                " all of the above", 4);
        addQuestion(q24); //adds a Question to database
        Question q25 = new Question("Biology","Surplus red blood cells, needed to" +
                " meet an emergency, are MAINLY stored in what organ of the human body? Is it the:",
                "pancreas", "spleen", "liver",
                "kidneys", 2);
        addQuestion(q25); //adds a Question to database
        Question q26 = new Question("Biology","When a human donor gives a pint" +
                " of blood, it usually requires how many weeks for the body RESERVE of red" +
                " corpuscles to be replaced? Is it:", "1 week", "3 weeks", "7 weeks",
                "21 weeks", 3);
        addQuestion(q26); //adds a Question to database
        Question q27 = new Question("Biology"," The several types of white blood" +
                " cells are sometime collectively referred to as:",
                "erythrocytes (pron: eh-rith-row-cites)",
                "leukocytes (pron: lew-kah-cites)",
                "erythroblasts (pron: eh-rith-rah-blast)",
                "thrombocytes (pron: throm-bow-cites)", 2);
        addQuestion(q27); //adds a Question to database
        Question q28 = new Question("Biology","The condition in which there is" +
                " a DECREASE in the number of white blood cells in humans is known as:",
                "leukocytosis (pron: lew-kO-sigh-toe-sis)",
                "leukopenia (pron: lew-kO-pea-nee-ah)\n",
                "leukemia (pron: lew-kee-me-ah)",
                "leukohyperia (pron: lew-kO-high-per-e-ah)", 2);
        addQuestion(q8); //adds a Question to database
        Question q29 = new Question("Biology","The smallest of the FORMED " +
                "elements of the blood are the:",
                "white cells", "red cells", "platelets",
                "erythrocytes", 3);
        addQuestion(q29); //adds a Question to database
        Question q30 = new Question("Biology","Which of the following statements" +
                " concerning platelets is INCORRECT. Platelets:",
                "contain DNA", "are roughly disk-shaped",
                "have little ability to synthesize proteins",
                "are between 1/2 and 1/3 the diameter of the red cell\n", 1);
        addQuestion(q30); //adds a Question to database
        Question q31 = new Question("Computer Science","Where does the execution" +
                " of the program starts?", "user-defined function",
                "main function",  "void function", "none of the mentioned",
                2);
        addQuestion(q31); //adds a Question to database
        Question q32 = new Question("Computer Science","What are mandatory parts " +
                "in the function declaration?", "return type, function name",
                "return type, function name, parameters",  "parameters, function name",
                "none of the mentioned",
                1);
        addQuestion(q32); //adds a Question to database
        Question q33 = new Question("Computer Science","What is the header file" +
                " for the string class?", "#include<ios>",
                "#include<str>",  "#include<string>", "none of the mentioned",
                3);
        addQuestion(q33); //adds a Question to database
        Question q34 = new Question("Computer Science","Which of the following " +
                "permits function overloading on c++?", "type",
                "number of arguments",  "type & number of arguments",
                "none of the mentioned",
                3);
        addQuestion(q34); //adds a Question to database
        Question q35 = new Question("Computer Science","In which of the following" +
                " we cannot overload the function?", "return function",
                "caller",  "called function", "none of the mentioned",
                1);
        addQuestion(q35); //adds a Question to database
        Question q36 = new Question("Computer Science","Overloaded functions are",
                "Very long functions that can hardly run",
                "One function containing another one or more functions inside it",
                "Two or more functions with the same name but different number of " +
                        "parameters or type", "none of the mentioned",
                3);
        addQuestion(q36); //adds a Question to database
        Question q37 = new Question("Computer Science","What will happen while" +
                " using pass by reference", "The values of those variables are passed to" +
                " the function so that it can manipulate them",
                "The location of variable in memory is passed to the function so that" +
                        " it can use the same memory area for its processing",  "The " +
                "function declaration should contain ampersand (& in its type declaration)",
                "none of the mentioned",
                2);
        addQuestion(q37); //adds a Question to database
        Question q38 = new Question("Computer Science","What should be passed " +
                "in parameters when function does not require any parameters?",
                "void",
                "blank space",  "both void & blank space",
                "none of the mentioned",
                2);
        addQuestion(q38); //adds a Question to database

        Question q39 = new Question("Computer Science","What are the advantages " +
                "of passing arguments by reference?", "Changes to parameter values within" +
                " the function also affect the original arguments", "There is need to copy " +
                "parameter values (i.e. less memory used)",  "There is no need to call " +
                "constructors for parameters (i.e. faster)", "All of the mentioned",
                4);
        addQuestion(q39); //adds a Question to database
        Question q40 = new Question("Computer Science","Which operator works only" +
                " with integer variables?", "increment", "decrement",
                "both increment & decrement", "none of the mentioned",
                3);
        addQuestion(q40); //adds a Question to database
        Question q41 = new Question("Physics","Which of the following is a " +
                "physical quantity that has a magnitude but no direction?", "Vector", "Frame of reference",
                "Resultant", "Scalar",
                4);
        addQuestion(q41); //adds a Question to database
        Question q42 = new Question("Physics","\tA man presses more weight on" +
                " earth at :", "Sitting position", "Standing Position",
                "Lying Position", "None of these",
                2);
        addQuestion(q42); //adds a Question to database
        Question q43 = new Question("Physics","A piece of ice is dropped in a " +
                "vesel containing kerosene. When ice melts, the level of kerosene will", "Rise", "Fall",
                "Remain Same", "None of these",
                2);
        addQuestion(q4); //adds a Question to database
        Question q44 = new Question("Physics","Young's modulus is the property of",
                "Gas only", "Both Solid and Liquid",
                "Liquid only", "Solid only",
                4);
        addQuestion(q44); //adds a Question to database
        Question q45 = new Question("Physics","\tAn artificial Satellite revolves" +
                " round the Earth in circular orbit, which quantity remains constant?",
                "Angular Momentum", "Linear Velocity",
                "Angular Displacement", "None of these",
                1);
        addQuestion(q45); //adds a Question to database
        Question q46 = new Question("Physics","Product of Force and Velocity" +
                " is called:", "Work", "Power",
                "Energy", "Momentum",
                2);
        addQuestion(q46); //adds a Question to database
        Question q47 = new Question("Physics","If electrical conductivity" +
                " increases with the increase of temperature of a substance, then it is a:",
                "Conductor", "Semiconductor",
                "Insulator", "Carborator",
                2);
        addQuestion(q47); //adds a Question to database
        Question q48 = new Question("Physics","Which one of the following has the" +
                " highest value of specific heat ?", "Alcohol", "Methane",
                "Kerosene", "Water",
                4);
        addQuestion(q48); //adds a Question to database
        Question q49 = new Question("Physics","Elecronegativity is the measure of:",
                "Metallic character", "Non-metallic character",
                "Basic Character", "None of these",
                2);
        addQuestion(q49); //adds a Question to database
        Question q50 = new Question("Physics","The rotational effect of a force" +
                " on a body about an axis of rotation is described in terms of the: ",
                "Centre of gravity", "Centripetal force",
                "Centrifugal force", "Moment of force",
                4);
        addQuestion(q50); //adds a Question to database
    }


    //changes to databases like adding columns
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    /**
     * this method is used to add all questions to the database
     *
     * @param question
     */
    private void addQuestion(Question question){
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_CATEGORY, question.getCategory());
        cv.put(QuestionsTable.COLUMN_ChoiceA, question.getChoiceA());
        cv.put(QuestionsTable.COLUMN_ChoiceB, question.getChoiceB());
        cv.put(QuestionsTable.COLUMN_ChoiceC, question.getChoiceC());
        cv.put(QuestionsTable.COLUMN_ChoiceD, question.getChoiceD());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNumberr());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Question> getAllQuestions() {

        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);

        if(c.moveToFirst()){
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setCategory(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY)));
                question.setChoiceA(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceA)));
                question.setChoiceB(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceB)));
                question.setChoiceC(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceC)));
                question.setChoiceD(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceD)));
                question.setAnswerNumberr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                questionList.add(question);

            }while(c.moveToNext()); //continue till cursor is at end of db
        }
        c.close(); //closes cursor
        return questionList;
    }

    public List<Question> getSpecificCategoryQuestions(String specificCategory) {

        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME +
                " WHERE category = " + "'" + specificCategory + "'", null);

        if(c.moveToFirst()){
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setCategory(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY)));
                question.setChoiceA(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceA)));
                question.setChoiceB(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceB)));
                question.setChoiceC(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceC)));
                question.setChoiceD(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceD)));
                question.setAnswerNumberr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                questionList.add(question);

            }while(c.moveToNext()); //continue till cursor is at end of db
        }
        c.close(); //closes cursor
        return questionList;
    }

}
