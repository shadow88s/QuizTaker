package com.example.quizztaker;
/**
 * Source-https://codinginflow.com/tutorials/android/quiz-app-with-sqlite/part-3-sqliteopenhelper
 */

import com.example.quizztaker.QuizContract.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QuizDb extends SQLiteOpenHelper {
    //Constsnats for SQLite database
    private static final String DATABASE_NAME = "Quiz.db";
    private static final int DATABASE_Version = 1;

    //used as a reference to add some values
    private SQLiteDatabase db;

    public QuizDb(Context context) {
        super(context, DATABASE_NAME,null, DATABASE_Version );
    }

    /**
     * method will be called when database is first accessed thjs is where
     * we creater our database
     * @param sqLiteDatabase
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        this.db = db;

        //string for SQL table creation
        final String SQL_CREATE_QUESTIONS_TABLE = "Create TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_ChoiceA + " TEXT, " +
                QuestionsTable.COLUMN_ChoiceB + " TEXT, " +
                QuestionsTable.COLUMN_ChoiceC + " TEXT, " +
                QuestionsTable.COLUMN_ChoiceD + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER" +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    //fills questions into Questions table
    private void fillQuestionsTable(){
        Question q1 = new Question("A is correct", " A", "B",
                " C", "D", 1);
        Question q2 = new Question("B is correct", " A", "B",
                " C", "D", 2);
        Question q3 = new Question("C is correct", " A", "B",
                " C", "D", 3);
        Question q4 = new Question("D is correct", " A", "B",
                " C", "D", 4);


        addQuestion(q1); //adds a Question to database
        addQuestion(q2); //adds a Question to database
        addQuestion(q3); //adds a Question to database
        addQuestion(q4); //adds a Question to database
    }

    //changes to databases like adding columns
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    private void addQuestion(Question question){
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_ChoiceA, question.getChoiceA());
        cv.put(QuestionsTable.COLUMN_ChoiceB, question.getChoiceB());
        cv.put(QuestionsTable.COLUMN_ChoiceC, question.getChoiceC());
        cv.put(QuestionsTable.COLUMN_ChoiceD, question.getChoiceD());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNumberr());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);

        if(c.moveToFirst()){
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setChoiceA(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceA)));
                question.setChoiceB(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceB)));
                question.setChoiceC(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceC)));
                question.setChoiceD(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_ChoiceD)));
                question.setAnswerNumberr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR));
                questionList.add(question);

            }while(c.moveToNext()); //continue till cursor is at end of db
        }

        c.close(); //closes cursor
        return questionList;
    }




}
