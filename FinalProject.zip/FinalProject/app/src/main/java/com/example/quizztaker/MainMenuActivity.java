package com.example.quizztaker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity
{
    private Button start_button;
    private Spinner category;
    private Spinner question;
    private Spinner round;


    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_menu);

        //hide action bar for this splash screen
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        start_button = (Button) findViewById(R.id.start_button);
        category = (Spinner) findViewById(R.id.category);
        question = (Spinner) findViewById(R.id.question);
        round = (Spinner) findViewById(R.id.round);


        String[] categorySpinner = new String[] {
                "History", "Astronomy", "Biology","Computer Science", "Physics"};
        ArrayAdapter<String> catAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, categorySpinner);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(catAdapter);


        String[] questionSpinner = new String[] {
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        ArrayAdapter<String> questionAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, questionSpinner);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        question.setAdapter(questionAdapter);

        String[] roundSpinner = new String[] {
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        ArrayAdapter<String> roundAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, roundSpinner);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        round.setAdapter(roundAdapter);


        start_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //send an intent to SignUpActivity
                Intent intent = new Intent(getApplication(), QuizActivity.class);
                intent.putExtra("category", category.getSelectedItem().toString());
                intent.putExtra("questionPerRound", question.getSelectedItem().toString());
                intent.putExtra("round", round.getSelectedItem().toString());
                startActivity(intent);
            }
        });
    }
}
