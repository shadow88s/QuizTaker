package com.example.quizztaker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * this class is the quiz activity
 * Source-https://codinginflow.com/tutorials/android/quiz-app-with-sqlite/part-3-sqliteopenhelper
 */
public class QuizActivity extends AppCompatActivity {

    private TextView score_text;
    private TextView question_text;
    private RadioGroup choices_radio_group;
    private RadioButton a_radio_button;
    private RadioButton b_radio_button;
    private RadioButton c_radio_button;
    private RadioButton d_radio_button;
    private TextView question_count_text;
    private Button submit_next_button;
    private TextView round_category_text;
    private static int round = 0;
    private static int rounds;
    private String Category;

    private ColorStateList textColorDefaultRb;

    private List<Question> questionList;
    private static int questionCounter = 0;
    private int questionCountTotal;
    private Question currentQuestion;
    private ArrayList<Integer> scores;

    private int score;
    private boolean answered; //true if question answered


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //hide action bar for this activity
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Intent intent = getIntent();
        String category = intent.getStringExtra("category");
        String questionPerRound = intent.getStringExtra("questionPerRound");
        rounds = Integer.parseInt(intent.getStringExtra("round"));
        scores = new ArrayList<>();

        score_text = (TextView) findViewById(R.id.score_text);
        score_text.setText("Score: 0"); //sets score to 0 first.
        round_category_text = (TextView) findViewById(R.id.round_category_text);
        question_text = (TextView) findViewById(R.id.question_text);
        choices_radio_group = (RadioGroup) findViewById(R.id.choices_radio_group);
        a_radio_button = (RadioButton) findViewById(R.id.a_radio_button);
        b_radio_button = (RadioButton) findViewById(R.id.b_radio_button);
        c_radio_button = (RadioButton) findViewById(R.id.c_radio_button);
        d_radio_button = (RadioButton) findViewById(R.id.d_radio_button);
        submit_next_button = (Button) findViewById(R.id.submit_next_button);
        question_count_text = (TextView) findViewById(R.id.question_count_text);
        textColorDefaultRb = a_radio_button.getTextColors();

        QuizDbHelper quizDbHelper = new QuizDbHelper(this);
        while(round < rounds){
            questionCounter = 0;
            questionList = quizDbHelper.getSpecificCategoryQuestions(category);
            questionCountTotal = Integer.parseInt(questionPerRound);
            Collections.shuffle(questionList); // shuffles question list
            showNextQuestion();
            round++;

            submit_next_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!answered) {
                        if (a_radio_button.isChecked() || b_radio_button.isChecked() ||
                                c_radio_button.isChecked() || d_radio_button.isChecked()) {
                            checkAnswer();
                        } else {
                            Toast.makeText(QuizActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        showNextQuestion();
                    }
                }
            });
        }

    }

    private void showNextQuestion() {
        //resets to default text colors (unecessary if we don't show correct answers after every question
        a_radio_button.setTextColor(textColorDefaultRb);
        b_radio_button.setTextColor(textColorDefaultRb);
        c_radio_button.setTextColor(textColorDefaultRb);
        d_radio_button.setTextColor(textColorDefaultRb);
        choices_radio_group.clearCheck(); //clears selection


        if(questionCounter < questionCountTotal) {
            currentQuestion = questionList.get(questionCounter);

            round_category_text.setText("Round: 1 -" + currentQuestion.getCategory());
            question_text.setText(currentQuestion.getQuestion()); //sets text to next question
            a_radio_button.setText(currentQuestion.getChoiceA());
            b_radio_button.setText(currentQuestion.getChoiceB());
            c_radio_button.setText(currentQuestion.getChoiceC());
            d_radio_button.setText(currentQuestion.getChoiceD());
            questionCounter++;
            //displays question number
            question_count_text.setText("Question: " + questionCounter + "/" + questionCountTotal);
            answered = false; //resets answered boolean
            submit_next_button.setText("submit");
        }else {
            //finishes activity
            // need to also go back to main menu
        }
    }


    private void checkAnswer() {
        answered = true;

        RadioButton rbSelected = findViewById(choices_radio_group.getCheckedRadioButtonId());
        int answerNr = choices_radio_group.indexOfChild(rbSelected) + 1;

        if (answerNr == currentQuestion.getAnswerNumberr()) {
            score++;
            score_text.setText("Score: " + score);
        }

        showSolution();
    }


    private void showSolution() {
        a_radio_button.setTextColor(Color.RED);
        b_radio_button.setTextColor(Color.RED);
        c_radio_button.setTextColor(Color.RED);
        d_radio_button.setTextColor(Color.RED);

        switch (currentQuestion.getAnswerNumberr()) {
            case 1:
                a_radio_button.setTextColor(Color.GREEN);
                question_text.setText("Answer A: is correct");
                break;
            case 2:
                b_radio_button.setTextColor(Color.GREEN);
                question_text.setText("Answer B is correct");
                break;
            case 3:
                c_radio_button.setTextColor(Color.GREEN);
                question_text.setText("Answer C is correct");
                break;
            case 4:
                d_radio_button.setTextColor(Color.GREEN);
                question_text.setText("Answer D is correct");
                break;
        }

        if (questionCounter < questionCountTotal) {
            submit_next_button.setText("Next");
        } else {
            submit_next_button.setText("Get Results");
        }
    }
}
