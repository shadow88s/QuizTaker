package com.example.quizztaker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Collections;
import java.util.List;

/**
 * Source-https://codinginflow.com/tutorials/android/quiz-app-with-sqlite/part-3-sqliteopenhelper
 */
public class QuizActivity extends AppCompatActivity {

    private TextView question_text;
    private RadioGroup choices_radio_group;
    private RadioButton a_radio_button;
    private RadioButton b_radio_button;
    private RadioButton c_radio_button;
    private RadioButton d_radio_button;
    private TextView answer_text;
    private TextView question_count_text;
    private Button submit_next_button;

    private ColorStateList textColorDefaultRb;

    private List<Question> questionList;
    private int questionCounter;
    private int questionCountTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered; //true if question answered


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //hide action bar for this activity
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        question_text = (TextView) findViewById(R.id.question_text);
        choices_radio_group = (RadioGroup) findViewById(R.id.choices_radio_group);
        a_radio_button = (RadioButton) findViewById(R.id.a_radio_button);
        b_radio_button = (RadioButton) findViewById(R.id.b_radio_button);
        c_radio_button = (RadioButton) findViewById(R.id.c_radio_button);
        d_radio_button = (RadioButton) findViewById(R.id.d_radio_button);
        answer_text = (TextView) findViewById(R.id.answer_text);
        submit_next_button = (Button) findViewById(R.id.submit_next_button);
        question_count_text = (TextView) findViewById(R.id.question_count_text);
        textColorDefaultRb = a_radio_button.getTextColors();

        QuizDbHelper quizDbHelper = new QuizDbHelper(this);
        questionList = quizDbHelper.getAllQuestions();
        questionCountTotal = questionList.size();Collections.shuffle(questionList); // shuffles question list

        showNextQuestion();


    }

    private void showNextQuestion() {
        //resets to default text colors (unecessary if we don't show correct answers after every question
        a_radio_button.setTextColor(textColorDefaultRb);
        b_radio_button.setTextColor(textColorDefaultRb);
        c_radio_button.setTextColor(textColorDefaultRb);
        d_radio_button.setTextColor(textColorDefaultRb);
        choices_radio_group.clearCheck(); //clears selection

        if(questionCounter < questionCountTotal) {
            currentQuestion = questionList.get(questionCounter);

            question_text.setText(currentQuestion.getQuestion()); //sets text to next question
            a_radio_button.setText(currentQuestion.getChoiceA());
            b_radio_button.setText(currentQuestion.getChoiceB());
            c_radio_button.setText(currentQuestion.getChoiceC());
            d_radio_button.setText(currentQuestion.getChoiceD());
            questionCounter++;
            //displays question number
            question_count_text.setText("Question: " + questionCounter + "/" + questionCountTotal);
            answered = false; //resets answered boolean
            submit_next_button.setText("confirm");
        }else {
            finish(); //finishes activity
            // need to also go back to main menu
        }


    }
}
