/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Howard Chen,
 * Final Project : Quiz Taker
 * Due: Aug 15, 2019
 * Purpose: This app is an android quiz taker app which challenges the user to multiple categories.
 * The app shows a good implementation of most of the features we learning in our CECS 453 Mobile
 * Application Development app. The app stores a sqlite database for the username/password and saved questions.
 */
package com.example.quiztaker;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class QuizActivity extends AppCompatActivity
{
    //declare control objects
    private TextView rounds;
    private TextView questions;
    private TextView question_text;
    private TextView option1;
    private TextView option2;
    private TextView option3;
    private TextView option4;
    private Button quit_button;
    private Button submit_button;

    private static int question_counter;
    private static int round_counter;
    private int num_of_questions;
    private int num_of_rounds;
    private boolean answered; //true if question answered
    private String user_answer;
    private String in_game_name;

    private Question currentQuestion;
    private List<Question> questionList;
    public static Map<Integer, Integer> rounds_questions;

    private static int new_question;
    private static int total_questions;
    private static int total_correct_answers;
    private static int correct_answers_per_round;
    private boolean isResultReady;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //create control objects
        rounds = (TextView) findViewById(R.id.round_text);
        questions = (TextView) findViewById(R.id.question_num);
        question_text = (TextView) findViewById(R.id.question_text);
        option1 = (TextView) findViewById(R.id.option1);
        option2 = (TextView) findViewById(R.id.option2);
        option3 = (TextView) findViewById(R.id.option3);
        option4 = (TextView) findViewById(R.id.option4);
        quit_button = (Button) findViewById(R.id.quit_button);
        submit_button = (Button) findViewById(R.id.submit_button);

        //hide action bar for this splash screen
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //get information that have been passed to this activity through intent
        Intent pre_intent = getIntent();
        String category = pre_intent.getStringExtra("category");
        num_of_rounds = Integer.parseInt(pre_intent.getStringExtra("num_of_rounds"));
        num_of_questions = Integer.parseInt(pre_intent.getStringExtra("num_of_questions"));
        in_game_name = pre_intent.getStringExtra("in_game_name");

        new_question = 0;
        isResultReady = false;
        total_questions = num_of_rounds * num_of_questions;
        total_correct_answers = 0;
        question_counter = 0;
        round_counter = 0;
        user_answer = "";
        correct_answers_per_round = 0;

        rounds_questions = new LinkedHashMap<>();

        //get all the questions that have the same category in the database
        QuizTakerDatabase quiz_db = new QuizTakerDatabase(this);
        questionList = quiz_db.getSpecificCategoryQuestions(category);

        //shuffle the all questions
        Collections.shuffle(questionList);

        if(question_counter < num_of_questions) {
            //show the question one after another
            showNextQuestion();
        }

        //go back to home menu if user clicks on quit button
        //this method is used to listen to logout event
        quit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //creating the dialog builder
                AlertDialog.Builder builder= new AlertDialog.Builder(QuizActivity.this);
                //set the title for the dialog
                builder.setTitle("Quit");
                //set the message
                builder.setMessage("Are you sure you want to quit?");
                //disable background
                builder.setCancelable(false);

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    //if user clicks cancel then do nothing
                    public void onClick(DialogInterface dialogInterface, int i) {}
                });

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    //if user clicks yes then go to log in page
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        finish();
                    }
                });

                builder.show();
            }
        });

        View.OnClickListener handler = new View.OnClickListener()
        {
            public void onClick(View v)
            {
                switch(v.getId())
                {
                    case R.id.option1:
                    {
                        user_answer = (String) option1.getText().toString();
                        option1.setBackgroundResource(R.color.white);
                        option2.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option3.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option4.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        break;
                    }
                    case R.id.option2:
                    {
                        user_answer = (String) option2.getText().toString();
                        option2.setBackgroundResource(R.color.white);
                        option1.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option3.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option4.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        break;
                    }
                    case R.id.option3:
                    {
                        user_answer = (String) option3.getText().toString();
                        option3.setBackgroundResource(R.color.white);
                        option1.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option2.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option4.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        break;
                    }
                    case R.id.option4:
                    {
                        user_answer = (String) option4.getText().toString();
                        option4.setBackgroundResource(R.color.white);
                        option1.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option2.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        option3.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
                        break;
                    }
                }
            }
        };
        findViewById(R.id.option1).setOnClickListener(handler);
        findViewById(R.id.option2).setOnClickListener(handler);
        findViewById(R.id.option3).setOnClickListener(handler);
        findViewById(R.id.option4).setOnClickListener(handler);

        //this method is used to listen to submit event
        submit_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if(isResultReady)
                {
                    int points_gain = 0;
                    int total_points = 0;

                    int percentage = (int) (((double) total_correct_answers / total_questions) * 100);

                    if(percentage >= 100)
                    {
                        points_gain = 5;
                    }
                    else if(percentage >= 90)
                    {
                        points_gain = 4;
                    }
                    else if(percentage >= 80)
                    {
                        points_gain = 3;
                    }
                    else if(percentage >= 70)
                    {
                        points_gain = 2;
                    }
                    else if(percentage >= 60)
                    {
                        points_gain = 1;
                    }
                    else if(percentage >= 50)
                    {
                        points_gain = 0;
                    }
                    else if(percentage >= 40)
                    {
                        points_gain = -1;
                    }
                    else if(percentage >= 30)
                    {
                        points_gain = -2;
                    }
                    else if(percentage >= 20)
                    {
                        points_gain = -3;
                    }
                    else if(percentage >= 10)
                    {
                        points_gain = -4;
                    }
                    else if(percentage >= 0)
                    {
                        points_gain = -5;
                    }


                    Cursor cursor = LogInActivity.db.getScores(in_game_name);
                    if(cursor.getCount() > 0)
                    {
                        total_points = points_gain + cursor.getInt(cursor.getColumnIndex(QuizTakerDatabase.COL_SCORES));
                    }

                    LogInActivity.db.updateScore(in_game_name, total_points);
                    Intent intent = new Intent(getApplication(), ResultActivity.class);
                    intent.putExtra("points_gain", "" + points_gain);
                    intent.putExtra("percentage","" + percentage);
                    intent.putExtra("total_correct_answers", "" + total_correct_answers);
                    intent.putExtra("total_questions", "" + total_questions);
                    startActivity(intent);

                    finish();
                }
                else
                {
                    if(!answered)
                    {
                        if(user_answer.equals(""))
                        {
                            Toast.makeText(getApplicationContext(), "Please select an answer", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            checkAnswer();
                        }
                    }
                    else
                    {
                        showNextQuestion();
                    }
                }
            }
        });
    }

    private void showNextQuestion()
    {
        if(new_question >= questionList.size())
        {
            new_question = 0;
        }

        //resets to default background
        option1.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
        option2.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
        option3.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);
        option4.setBackgroundResource(R.drawable.zinc_rounded_rectangle_border);

        //display the current round
        rounds.setText("Round " + (round_counter + 1));

            //display the current question
            currentQuestion = questionList.get(new_question++);

            //shuffle all the options
            List<String> options = new ArrayList<>();
            options.add(currentQuestion.getChoiceA());
            options.add(currentQuestion.getChoiceB());
            options.add(currentQuestion.getChoiceC());
            options.add(currentQuestion.getChoiceD());

            Collections.shuffle(options);

            question_text.setText(currentQuestion.getQuestion());

            questions.setText("Questions: " + (question_counter + 1) + "/" + num_of_questions);
            //display all the options
            option1.setText(options.get(0));
            option2.setText(options.get(1));
            option3.setText(options.get(2));
            option4.setText(options.get(3));

            //increment the question_counter
            question_counter++;

            //resets answered boolean
            answered = false;

            submit_button.setText(R.string.submit);
    }

    private void checkAnswer()
    {
        answered = true;

        if(user_answer.equals(currentQuestion.getAnswer()))
        {
            Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT).show();
            total_correct_answers++;
            correct_answers_per_round++;
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_SHORT).show();
        }

        if(question_counter >= num_of_questions && round_counter < num_of_rounds)
        {
            rounds_questions.put(round_counter + 1, correct_answers_per_round);
            correct_answers_per_round = 0;
            round_counter++;
            question_counter = 0;
        }

        showSolution();
    }

    private void showSolution()
    {
        String optionA = (String) option1.getText().toString();
        String optionB = (String) option2.getText().toString();
        String optionC = (String) option3.getText().toString();
        String optionD = (String) option4.getText().toString();

        if(optionA.equals(currentQuestion.getAnswer()))
        {
            option1.setBackgroundResource(R.color.green);
        }
        else
        {
            option1.setBackgroundResource(R.color.red);
        }

        if(optionB.equals(currentQuestion.getAnswer()))
        {
            option2.setBackgroundResource(R.color.green);
        }
        else
        {
            option2.setBackgroundResource(R.color.red);
        }

        if(optionC.equals(currentQuestion.getAnswer()))
        {
            option3.setBackgroundResource(R.color.green);
        }
        else
        {
            option3.setBackgroundResource(R.color.red);
        }

        if(optionD.equals(currentQuestion.getAnswer()))
        {
            option4.setBackgroundResource(R.color.green);
        }
        else
        {
            option4.setBackgroundResource(R.color.red);
        }

        if(round_counter < num_of_rounds)
        {
            submit_button.setText("Next");
        }

        if(round_counter >= num_of_rounds)
        {
            submit_button.setText("Get Results");
            isResultReady = true;
        }
    }
}
