package com.example.quiztaker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity
{
    //declare control objects
    private TextView rounds;
    private TextView questions;
    private TextView question_text;
    private TextView option1;
    private TextView option2;
    private TextView option3;
    private TextView option4;
    private Button quit_button;
    private Button submit_button;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //create control objects
        rounds = (TextView) findViewById(R.id.round_text);
        questions = (TextView) findViewById(R.id.question_num);
        question_text = (TextView) findViewById(R.id.question_text);
        option1 = (TextView) findViewById(R.id.option1);
        option2 = (TextView) findViewById(R.id.option2);
        option3 = (TextView) findViewById(R.id.option3);
        option4 = (TextView) findViewById(R.id.option4);
        quit_button = (Button) findViewById(R.id.quit_button);
        submit_button = (Button) findViewById(R.id.submit_button);

        //hide action bar for this splash screen
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //get information that have been passed to this activity through intent
        Intent intent = getIntent();
        String category = intent.getStringExtra("category");
        int num_of_rounds = Integer.parseInt(intent.getStringExtra("num_of_rounds"));
        int num_of_questions = Integer.parseInt(intent.getStringExtra("num_of_questions"));

        //get all the questions that have the same category in the database

        for(int i = 1; i <= num_of_rounds; i++)
        {
            //display current round
            rounds.setText("Round " + i);

            for(int j = 1; j <= num_of_questions; j++)
            {
                //display current question
                questions.setText("Questions: " + j + "/" + num_of_questions);
            }
        }
    }
}
