package com.example.quiztaker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * A class which uses SQLite to create account database for quiz taker game
 */
public class QuizTakerDatabase extends SQLiteOpenHelper
{
    //declare and initialize variables for database tables and columns
    public static final String DATABASE_NAME = "QuizTaker.db";
    public static final int DATABASE_VERSION = 1;

    private static final String TABLE_ACCOUNT = "accounts";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_EMAIL = "email";
    public static final String COL_IN_GAME_NAME = "ingamename";

    private static final String TABLE_QUESTION = "questions";
    public static final String COL_CATEGORY = "category";
    public static final String COL_QUESTION = "question";
    public static final String COL_ANSWER_1 = "answer_1";
    public static final String COL_ANSWER_2 = "answer_2";
    public static final String COL_ANSWER_3 = "answer_3";
    public static final String COL_ANSWER_4 = "answer_4";
    public static final String COL_CORRECT_ANSWER = "correct_answer";

    private static final String TABLE_LEADERBOARD = "leaderboards";

    /**
     * Create database through constructor
     */
    public QuizTakerDatabase(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Create tables in database
     */
    public void onCreate(SQLiteDatabase db)
    {
        //create accounts table
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ACCOUNT + "(" + COL_USERNAME + " TEXT PRIMARY KEY, " + COL_PASSWORD + " TEXT, " + COL_EMAIL + " TEXT, " + COL_IN_GAME_NAME + " TEXT);");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_QUESTION + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_CATEGORY + " TEXT, " + COL_QUESTION + " TEXT, " + COL_ANSWER_1 + " TEXT, " + COL_ANSWER_2 + " TEXT, " + COL_ANSWER_3 + " TEXT, " + COL_ANSWER_4 + " TEXT, " + COL_CORRECT_ANSWER + " TEXT);");
    }

    /**
     * Drop all the tables and recreate them to make any changes
     */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCOUNT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTION);
        //call onCreate method to recreate tables
        onCreate(db);
    }

    /**
     *This method is used to add new account to database
     */
    public void insertAccount(String username, String password, String email, String inGameName)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        //adding new account in accounts table
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        values.put(COL_EMAIL, email);
        values.put(COL_IN_GAME_NAME, inGameName);
        db.insert(TABLE_ACCOUNT, null, values);
    }

    /**
     * This method is used to add new question to database
     */
    public void insertQuestion(String category, String question, String answer1, String answer2, String answer3, String answer4, String correct_answer)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        //adding new question in questions table
        ContentValues values = new ContentValues();
        values.put(COL_CATEGORY, category);
        values.put(COL_QUESTION, question);
        values.put(COL_ANSWER_1, answer1);
        values.put(COL_ANSWER_2, answer2);
        values.put(COL_ANSWER_3, answer3);
        values.put(COL_ANSWER_4, answer4);
        values.put(COL_CORRECT_ANSWER, correct_answer);
        db.insert(TABLE_QUESTION, null, values);
    }

    /**
     * This method is used to either update in-game name or password
     * @param column column in the table
     * @param value new value that will be updated
     */
    public void updateAccount(String column, String value, String key, String keyValue)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        //update data in accounts table
        ContentValues newValue = new ContentValues();
        newValue.put(column, value);
        db.update(TABLE_ACCOUNT, newValue, key + "=?", new String[] {keyValue});
    }

    /**
     * Find an account by matching username
     * @param value unique username or in-game name that is being searched for
     * @return cursor object which will be used to retrieve data in database
     */
    public Cursor getAccountInfo(String value, String type)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "";

        if(type.equals("username"))
        {
            //a query that will get the username and password that match the where clause
            query = "SELECT * FROM " + TABLE_ACCOUNT + " where " + COL_USERNAME + " = '" + value + "';";
        }
        else if(type.equals("in_game_name"))
        {
            //a query that will get the in-game name that match the where clause
            query = "SELECT " + COL_IN_GAME_NAME + " from " + TABLE_ACCOUNT + " where " + COL_IN_GAME_NAME + " = '" + value + "';";
        }

        //getting results in cursor which allow us to read result from the database
        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToNext();
        return cursor;
    }

    public Cursor getQuestionInfo(String category)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_QUESTION + " where " + COL_CATEGORY + " = '" + category + "';";

        //getting results in cursor which allow us to read result from the database
        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToNext();
        return cursor;
    }

    public Cursor getQuestionCategory()
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT " + COL_CATEGORY + " FROM " + TABLE_QUESTION + ";";

        //getting results in cursor which allow us to read result from the database
        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToNext();

        return cursor;
    }
}
