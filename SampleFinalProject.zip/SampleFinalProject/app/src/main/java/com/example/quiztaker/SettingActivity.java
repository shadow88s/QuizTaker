package com.example.quiztaker;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/**
 * An activity that acts as a dialog and has multiple settings for user
 * to change such as in-game name change, password change, help, logout
 */
public class SettingActivity extends AppCompatActivity
{
    //declare control objects
    private Button change_name_button;
    private Button change_password_button;
    private Button help_button;
    private Button log_out_button;
    private Button add_question_button;
    private TextView welcome_text;
    private TextView exit;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        // Reading the value of the intent sent here
        Intent intent = getIntent();

        //getting the value by "user_type" tag
        final String user_type = intent.getStringExtra("user_type");

        //if this is an admin then we use the layout with "add question" feature
        if (user_type.equals("administrator"))
        {
            setContentView(R.layout.activity_setting_admin);
            add_question_button = (Button) findViewById(R.id.add_question_button);

            //adjust the size of the setting dialog
            this.getWindow().setLayout(1300,1650);

            //this method is used to listen to add question event
            //this feature is for admin only
            add_question_button.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    //send an intent to AddQuestionActivity
                    Intent intent = new Intent(getApplication(), AddQuestionActivity.class);
                    intent.putExtra("user_type", user_type);
                    startActivity(intent);
                    finish();
                }
            });
        }
        //if not then we use layout without "add question" feature
        else
        {
            setContentView(R.layout.activity_setting);

            //adjust the size of the setting dialog
            this.getWindow().setLayout(1300,1450);
        }

        //creates control objects
        change_name_button = (Button) findViewById(R.id.change_name_button);
        change_password_button = (Button) findViewById(R.id.change_password_button);
        help_button = (Button) findViewById(R.id.help_button);
        log_out_button = (Button) findViewById(R.id.log_out_button);
        welcome_text = (TextView) findViewById(R.id.welcome_text);
        exit = (TextView) findViewById(R.id.exit);

        final Cursor cursor = LogInActivity.db.getAccountInfo(user_type, "username");

        //display welcome message in setting dialog
        //in-game name column is at index 3
        welcome_text.setText("Welcome, " + cursor.getString(3) + "!");

        //disable the background, make it untouchable
        this.setFinishOnTouchOutside(false);

        //dismiss this activity if user press "X" button
        exit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                finish();
            }
        });

        //this method is used to listen to ChangeNameActivity dialog
        change_name_button.setOnClickListener(new View.OnClickListener()
        {
            /**
             * change_name_button clicks sends user to ChangeNameActivity
             */
            public void onClick(View v)
            {
                //send an intent to ChangeNameActivity
                Intent intent = new Intent(getApplication(), ChangeNameActivity.class);
                intent.putExtra("user_type", user_type);
                intent.putExtra("user_name", cursor.getString(0));
                startActivity(intent);
                finish();
            }
        });

        //this method is used to listen to ChangePasswordActivity dialog
        change_password_button.setOnClickListener(new View.OnClickListener()
        {
            /**
             * change_password_button clicks sends user to ChangePasswordActivity
             * @param view
             */
            @Override
            public void onClick(View view)
            {
                //send an intent to ChangeNameActivity
                Intent intent = new Intent(getApplication(), ChangePasswordActivity.class);
                intent.putExtra("user_type", user_type);
                intent.putExtra("user_name", cursor.getString(0));
                intent.putExtra("password", cursor.getString(1));
                startActivity(intent);
                finish();
            }
        });

        //this method is used to listen to Help event
        help_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //send an intent to HelpActivity
                Intent intent = new Intent(getApplication(), HelpActivity.class);
                intent.putExtra("user_type", user_type);
                startActivity(intent);
                finish();
            }
        });

        //this method is used to listen to logout event
        log_out_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //creating the dialog builder
                AlertDialog.Builder builder= new AlertDialog.Builder(SettingActivity.this);
                //set the title for the dialog
                builder.setTitle("Logout");
                //set the message
                builder.setMessage("Are you sure you want to logout?");
                //disable background
                builder.setCancelable(false);

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    //if user clicks cancel then do nothing
                    public void onClick(DialogInterface dialogInterface, int i) {}
                });

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    //if user clicks yes then go to log in page
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        Intent intent = new Intent(getApplication(), LogInActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });

                builder.show();
            }
        });
    }
}


