package com.example.quiztaker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import com.example.quiztaker.QuizContract.*;

/**
 * An activity which lets the user to select what category they want to
 * be tested, how many questions they want to be asked, and how many rounds
 * they want to play.  This activity also has setting and trophy features
 */
public class HomeMenuActivity extends AppCompatActivity
{
    //declare control objects
    private ImageView setting;
    private ImageView trophy;
    private Button start_button;
    private Spinner category_spinner;
    private Spinner rounds_spinner;
    private Spinner questions_spinner;

    private ArrayList<String> category_list;
    private final String[] ROUNDS = {"1", "2" , "3" , "4", "5"};
    private final String[] QUESTIONS = {"1", "2" , "3" , "4", "5", "6", "7", "8", "9", "10"};

    private String category;
    private String round;
    private String question;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_menu);

        //create control objects
        setting = (ImageView)findViewById(R.id.setting_image);
        trophy = (ImageView) findViewById(R.id.trophy_image);
        start_button = (Button) findViewById(R.id.start_button);
        category_spinner = (Spinner) findViewById(R.id.category);
        rounds_spinner = (Spinner) findViewById(R.id.round);
        questions_spinner = (Spinner) findViewById(R.id.question);

        QuizTakerDatabase db = new QuizTakerDatabase(this);

        //getting category from the database and store it in category_list
        category_list = new ArrayList<>();
        Cursor cursor = db.getQuestionCategory();

        //check if there is any category is in the database
        if(cursor.getCount() > 0)
        {
            do
            {
                //add category to the list
                category_list.add(cursor.getString(cursor.getColumnIndex(QuestionsTable.COLUMN_CATEGORY)));
            }while(cursor.moveToNext());
        }

        //data adapter for category spinner control
        ArrayAdapter<String> category_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, category_list);
        category_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category_spinner.setAdapter(category_adapter);

        //data adapter for category spinner control
        ArrayAdapter<String> rounds_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, ROUNDS);
        rounds_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rounds_spinner.setAdapter(rounds_adapter);

        //data adapter for category spinner control
        ArrayAdapter<String> questions_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, QUESTIONS);
        questions_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        questions_spinner.setAdapter(questions_adapter);

        //hide action bar for this splash screen
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //this method is used to listen to setting dialog
        setting.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Reading the value of the intent sent here
                Intent intent = getIntent();
                //getting the value by "user_type" tag
                String user_type = intent.getStringExtra("user_type");

                //send an intent to SettingActivity
                intent = new Intent(getApplication(), SettingActivity.class);
                intent.putExtra("user_type", user_type);
                startActivity(intent);
            }
        });

        //get what category the user wants to be tested on
        category_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                category = (String) parent.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        //get how many rounds user wants to play
        rounds_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                round = (String) parent.getSelectedItem();
            }

            //a callback method to be invoked when the selection disappears
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        //get how many questions user wants to play per round
        questions_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                question = (String) parent.getSelectedItem();
            }

            //a callback method to be invoked when the selection disappears
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        //this method is used to listen to start quiz event
        start_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = getIntent();
                String in_game_name = intent.getStringExtra("in_game_name");
                String user_type = intent.getStringExtra("user_type");

                intent = new Intent(getApplication(), QuizActivity.class);
                intent.putExtra("user_type", user_type);
                intent.putExtra("in_game_name", in_game_name);
                intent.putExtra("category", category);
                intent.putExtra("num_of_rounds", round);
                intent.putExtra("num_of_questions", question);
                startActivity(intent);
            }
        });

        //this method is used when user clicks on trophy image
        trophy.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(getApplication(), LeaderBoardActivity.class);
                startActivity(intent);
            }
        });
    }
}
