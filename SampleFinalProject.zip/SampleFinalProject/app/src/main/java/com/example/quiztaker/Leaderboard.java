/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Tien Huynh, Howard Chen
 * Final Project : Quiz Taker
 * Due: Aug 15, 2019
 * Purpose: This app is an android quiz taker app which challenges the user to multiple categories.
 * The app shows a good implementation of most of the features we learning in our CECS 453 Mobile
 * Application Development app. The app stores a sqlite database for the username/password and saved questions.
 */

package com.example.quiztaker;

public class Leaderboard
{
    private String in_game_name;
    private int scores;

    public Leaderboard(String in_game_name, int scores)
    {
        this.in_game_name = in_game_name;
        this.scores = scores;
    }

    public String getInGameName()
    {
        return in_game_name;
    }

    public int getScores()
    {
        return scores;
    }
}
