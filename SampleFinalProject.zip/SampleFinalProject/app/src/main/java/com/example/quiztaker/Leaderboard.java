package com.example.quiztaker;

public class Leaderboard
{
    private String in_game_name;
    private int scores;

    public Leaderboard(String in_game_name, int scores)
    {
        this.in_game_name = in_game_name;
        this.scores = scores;
    }

    public String getInGameName()
    {
        return in_game_name;
    }

    public int getScores()
    {
        return scores;
    }
}
