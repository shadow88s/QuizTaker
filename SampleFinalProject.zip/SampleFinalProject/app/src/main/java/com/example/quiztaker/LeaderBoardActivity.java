package com.example.quiztaker;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class LeaderBoardActivity extends AppCompatActivity
{
    private RecyclerView recycler_view;

    private List<Leaderboard> leaderboardList;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ranking_leaderboard);

        recycler_view = (RecyclerView) findViewById(R.id.recycler_view);

        leaderboardList = new ArrayList<>();

        QuizTakerDatabase db = new QuizTakerDatabase(this);

        Cursor cursor = db.getAllScores();

        do
        {
            //get in_game_name
            String name = cursor.getString(cursor.getColumnIndex(QuizTakerDatabase.COL_IN_GAME_NAME));
            //get scores of particular player
            int scores = cursor.getInt(cursor.getColumnIndex(QuizTakerDatabase.COL_SCORES));

            Leaderboard player = new Leaderboard(name, scores);

            //add to the leaderboardList
            leaderboardList.add(player);
        }while(cursor.moveToNext());

        //get all the ranks as a recycler view
        recycler_view.setAdapter(new LeaderboardRecyclerViewAdapter(leaderboardList));
    }
}
