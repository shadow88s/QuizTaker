/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Tien Huynh, Howard Chen
 * Final Project : Quiz Taker
 * Due: Aug 15, 2019
 * Purpose: This app is an android quiz taker app which challenges the user to multiple categories.
 * The app shows a good implementation of most of the features we learning in our CECS 453 Mobile
 * Application Development app. The app stores a sqlite database for the username/password and saved questions.
 */

package com.example.quiztaker;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class LeaderBoardActivity extends AppCompatActivity
{
    private RecyclerView recycler_view;

    private List<Leaderboard> leaderboardList;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ranking_leaderboard);

        this.getWindow().setLayout(1300,1650);

        recycler_view = (RecyclerView) findViewById(R.id.recycler_view);

        leaderboardList = new ArrayList<>();

        QuizTakerDatabase db = new QuizTakerDatabase(this);

        Cursor cursor = db.getAllScores();

        if(cursor.getCount() > 0)
        {
            do
            {
                //get in_game_name
                String name = cursor.getString(cursor.getColumnIndex(QuizTakerDatabase.COL_IN_GAME_NAME));
                //get scores of particular player
                int scores = cursor.getInt(cursor.getColumnIndex(QuizTakerDatabase.COL_SCORES));

                Leaderboard player = new Leaderboard(name, scores);

                //add to the leaderboardList
                leaderboardList.add(player);
            }while(cursor.moveToNext());

            //get all the ranks as a recycler view
            recycler_view.setAdapter(new LeaderboardRecyclerViewAdapter(leaderboardList));
        }
    }
}
